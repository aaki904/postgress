const express = require('express');
const otpGenerator = require('otp-generator');
const app = express();
const bodyparser = require('body-parser');


const apiRouter = require('./api/routes/routes');

app.use(bodyparser.urlencoded({extended : true}));
app.use(bodyparser.json());

app.get('/',(req,res)=>{
   res.send("API is runing")
})

app.use('/api',apiRouter);


app.listen(3000,console.log('server connected at port 3000'));
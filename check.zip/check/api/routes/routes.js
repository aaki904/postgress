const express = require('express');
const otpGenerator = require('otp-generator'); 
const router = express.Router();
const User = require('./auth');

router.post('/city',User.citydata);
router.get('/donate',User.donateamount);
router.post('/reqamount',User.requestamount);
router.post('/signup',User.signuppage);
router.post('/login',User.loginpage)
router.post('/register',User.registration);
 router.get('/showdata',User.showuserdata);
 router.post('/deletedata',User.deleteuserdata);
 router.post('/updatedata',User.updateuserdata);



module.exports = router;



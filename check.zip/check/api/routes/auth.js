const User = require('../controller/usercontroller');

module.exports.donateamount = (req,res,next)=>{
    var data = req.body;
    User.donate(data).then((responsedata)=>{
        res.json(responsedata)
    }).catch((err)=> next(err))
}

module.exports.requestamount = (req,res,next)=>{
    var data = req.body;
    User.reqamount(data).then((responsedata)=>{
        res.json(responsedata)
    }).catch((err)=> next(err))
}

module.exports.loginpage = (req,res,next)=>{
    var data = req.body;
    User.login(data).then((responsedata)=>{
        res.json(responsedata)
    }).catch((err)=> next(err))
}

module.exports.signuppage =(req,res,next) => {
    var data = req.body;
    User.signup(data).then((responsedata)=>{
        res.json(responsedata)
    }).catch((err)=>next(err))
}

module.exports.citydata =(req,res,next) => {
    var data = req.body;
    User.city(data).then((responsedata)=>{
        res.json(responsedata)
    }).catch((err)=>next(err))
}
module.exports.registration =(req,res,next) => {
    var data = req.body;
    // console.log(data)
    User.register(data).then((responseData)=>{
        res.json(responseData)
    }).catch((err) => next(err))

}

module.exports.showuserdata=(req,res,next) => {
    //var data= req.body;
    User.showdata().then((responseData)=>{
        res.json(responseData)
    }).catch((err)=> next(err))
}

module.exports.deleteuserdata=(req,res,next) => {
    var data= req.body;
    User.deletedata(data).then((responseData)=>{
        res.json(responseData)
    }).catch((err)=> next(err))
}

module.exports.updateuserdata=(req,res,next) => {
    var data= req.body;
    User.updatedata(data).then((responseData)=>{
        res.json(responseData)
    }).catch((err)=> next(err))
}
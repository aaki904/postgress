const client = require('../models/connection');
const otpGenerator = require('otp-generator'); 


module.exports.donate=(data)=>{
    return new Promise((resolve,reject)=>{
        userid=data.userid;
        donate=data.donate;
        remark=data.remark;
        id = data.id;
        const sql=`select * from requesttable where id='${id}' `
        client.query(sql,(err,res1)=>{
            var r_amount = res1.rows[0].r_amount;
            var c_amount = res1.rows[0].c_amount;
           
            if(err)
            {
                const data = {
                             "success":false,
                              "message":"wrong1"
                                 }
                             resolve(data)  
            }
            else{

                c_amount=c_amount+donate;
              
                if(r_amount>=c_amount){
             
             const sql2 = `update requesttable set c_amount = '${c_amount}' where id = '${id}'`
             client.query(sql2,(err,res2)=>{
                 if(err)
                 {
                  const data = {
                     "success":false,
                      "message":"wrong2"
                         }
                     resolve(data) 
                     console.log(err)
                 }
                 else{
                      const data = {
                     "success":true,
                     "message":"amount is donated",
                     "collected amount":c_amount
                      }
                     resolve(data)
                      }
                 })
              }
              else{
                   const data = {
                  "success":false,
                  "message":"amount is exceed"
                    }
                  resolve(data)
                  }

            }

           
                })
                
    })
}

// module.exports.donate=(data)=>{
//     return new Promise((resolve,reject)=>{
//         userid=data.userid;
//         donate=data.donate;
//         remark=data.remark;
//         id = data.id;
       
//         const sql=`select * from rerquest_amount where id='${id}' `
//         client.query(sql,(err,res1)=>{
//             var r_amount = res1.rows[0].r_amount;
//             var c_amount = res1.rows[0].c_amount;
//           if(err)
//             {
//                 const data = {
//                     "success":false,
//                     "message":"wrong"
//                      }
//                     resolve(data) 
//             }
//             else{
//                 const data = {
//                     "success":true,
//                     "message":"show",
                   
//                      }
//                     resolve(data)
                    
//                     if(r_amount>=c_amount){
//                         c_amount=c_amount+donate;
//                         const sql2 = `update rerquest_amount set c_amount = '${c_amount}' where id = '${id}'`
//                         client.query(sql2,(err,res2)=>{
//                             if(err)
//                             {
//                                 const data = {
//                                     "success":false,
//                                     "message":"wrong"
//                                      }
//                                     resolve(data) 
//                             }
//                             else{
//                                  const data = {
//                                       "success":true,
//                                      "message":"amount is donated",
                                   
//                                      }
//                                     resolve(data)
//                                 }
//                         })
//                      }
//                      else{
//                         const data = {
//                             "success":false,
//                             "message":"amount is exceed"
//                              }
//                             resolve(data)
//                      }

//                }

              
//         })
//     })
// }


module.exports.reqamount=(data)=>{
    return new Promise((resolve,reject)=>{
        ngoname = data.ngoname;
        r_amount = data.r_amount;
        c_amount = data.c_amount;
       
        const sql = `insert into requesttable(ngoname,r_amount,c_amount) values('${ngoname}','${r_amount}','${c_amount}')`
        client.query(sql,(err,res1)=>{
            if(err)
            {
                const Data = {
                  "success":false,
                  "message":"wrong"
                   }
                  resolve(Data) 
                  console.log(err)
               
            }
            else{
                const Data = {
                    "success":true,
                    "message":"insert sucessfully",
                   
                     }
                    resolve(Data) 
            }
        })
    })
}








// module.exports.login=(data)=>{
//         return new Promise((resolve,reject)=>{
//             number = data.number;
//             const check =`select from signup where number = '${number}'`;
//             client.query(check,(err,res1)=>{
//                 if(err)
//                 {
//                     const Data = {
//                         "success":false,
//                         "message":"wrong"
//                     }
//                     resolve(Data)
//                 }
//                 else{
                   
//                     if(res1.rows.length>0)
//                     {
//                         var getotp = otpGenerator.generate(6, {
//                             upperCase: false,
//                             specialChars: false,
//                             digits: true,
//                             alphabets: false
//                         });
                       
//                         const check2 = `update otp set otp = '${getotp}'where number = '${number}'`
//                         client.query(check2,(err,res2)=>{
//                             if(err)
//                             {
//                                 const Data = {
//                                     "success":false,
//                                     "message":"wrong"
//                                 }
//                                 resolve(Data)
//                             }
//                             else{
//                                 const Data = {
//                                     "success":true,
//                                     "message":"update successfully"
//                                 }
//                                 resolve(Data)
    
//                             }
//                         })
//                     }
//                     else{
//                         const check3 = `insert into otp (number) values('${number}')`
//                         client.query(check3,(err,res3)=>{
//                             if(err)
//                             {
//                                 const Data = {
//                                     "success":false,
//                                     "message":"wrong"
//                                 }
//                                 resolve(Data)
//                             }
//                             else{
//                                 const Data = {
//                                     "success":true,
//                                     "message":"insert successfully"
//                                 }
//                                 resolve(Data)
//                             }
//                         })
//                     }
//                 }
//             })
//         })
    
//     }
    
// module.exports.login=(data)=>{
//     return new Promise((resolve,reject)=>{
//         number = data.number;
//         const check =`select from otp where number = '${number}'`;
//         client.query(check,(err,res1)=>{
//             if(err)
//             {
//                 const Data = {
//                     "success":false,
//                     "message":"wrong"
//                 }
//                 resolve(Data)
//             }
//             else{
//                 var getotp = otpGenerator.generate(6, {
//                     upperCase: false,
//                     specialChars: false,
//                     digits: true,
//                     alphabets: false
//                 });
//                 if(res1.rows.length>0)
//                 {
                    
                   
//                     const check2 = `update otp set otp = '${getotp}'where number = '${number}'`
//                     client.query(check2,(err,res2)=>{
//                         if(err)
//                         {
//                             const Data = {
//                                 "success":false,
//                                 "message":"wrong"
//                             }
//                             resolve(Data)
//                         }
//                         else{
//                             const Data = {
//                                 "success":true,
//                                 "message":"update successfully"
//                             }
//                             resolve(Data)

//                         }
//                     })
//                 }
//                 else{
//                     const check3 = `insert into otp (otp,number) values('${getotp}','${number}')`
//                     client.query(check3,(err,res3)=>{
//                         if(err)
//                         {
//                             const Data = {
//                                 "success":false,
//                                 "message":"wrong"
//                             }
//                             resolve(Data)
//                         }
//                         else{
//                             const Data = {
//                                 "success":true,
//                                 "message":"insert successfully"
//                             }
//                             resolve(Data)
//                         }
//                     })
//                 }
//             }
//         })
//     })

// }

module.exports.signup=(data)=>{
    return new Promise((resolve,reject)=>{

        number = data.number;
        state = data.state;
        city = data.city;
        type = data.type;
        const check = `select * from signup where number = '${number}'`;
        client.query(check,(err,res)=>{
            if(err){
                const Data = {
                    "success":false,
                    "message":"wrong"
                }
                resolve(Data)
            }
            else{
                if(res.rows.length>0)
                {
                    const Data = {
                        "success":true,
                        "message":"number already existed"
                    }
                    resolve(Data)
                }
                else{
                     
                   const sql = `insert into signup (number,state,city,type) values('${number}','${state}','${city}','${type}')`;
                   client.query(sql,(err,res1)=>{
                       if(err){
                        const Data = {
                            "success":false,
                            "message":"error"
                        }
                        resolve(Data)
                       }
                       else{
                        const Data = {
                            "success":true,
                            "message":"data inserted"
                        }
                        resolve(Data)
                       }
                   })
                }
            }
        })
    })
}

module.exports.city= (data)=>{
  return new Promise((resolve,reject)=>{
      id =data.id;
     
    const sql0 = `select name from cities where  state_id = '${id}'`;
    client.query(sql0,(err,ress)=>{
        if(err)
        {
            const Data = {
                "success": false,
                "message": 'wrong'
            }
            resolve(Data)
        }else
        {
            
            const Data = {
                "success": true,
                "message": 'cityes name show',
               "data":ress.rows
                
            }
            // console.log(ress.rows)
            resolve(Data)
        }
  })
})
}

module.exports.register = (data) => {
    return new Promise((resolve, reject) => {

        var email = data.email;
        const chk1 = `select * from usertbl where email = '${email}'`;
        // console.log(sql);
        client.query(chk1, (err, res1) => {
            if (err) {
                const Data = {
                    "success": false,
                    "message": 'Something Went wrong'
                }
                resolve(Data)
                console.log(err)
            }
            else {
                if(res1.rows.length>0)
                {
                    const Data = {
                        "success": false,
                        "message": 'Already existed'
                    }
                    resolve(Data)
                }else
                {
                    const sql1 = `insert into usertbl (email) values ('${email}')`;
                    client.query(sql1,(err,ress)=>{
                        if(err)
                        {
                            const Data = {
                                "success": false,
                                "message": 'Error1'
                            }
                            resolve(Data)
                        }else
                        {
                            const Data = {
                                "success": true,
                                "message": 'inserted successfully'
                            }
                            resolve(Data)
                        }
                    })
                }
            }
    
                
        })
    })
}

module.exports.showdata = () => {
    return new Promise((resolve, reject) => {
        const sql2 = `select * from usertbl`;
        //console.log(sql2);
        client.query(sql2, (err, res2) => {
            if (err) {
                const Data = {
                    "success": false,
                    "message": 'Error occour'
                }
                resolve(Data)
            } else {
                const Data = {
                    "success": true,
                    "message": 'ALL DATA'
                }
                resolve(Data)
                console.log(res2)
            }
        })
    })
}

module.exports.deletedata = (data) => {
    return new Promise((resolve, reject) => {
        console.log(data)
        id = data.id;
        const sql3 = `delete from usertbl where id= '${id}' `;
        //console.log(sql2);
        client.query(sql3, (err, res2) => {
            if (err) {
                const Data = {
                    "success": false,
                    "message": 'Error occour'
                }
                resolve(Data)
            } else {
                const Data = {
                    "success": true,
                    "message": 'ALL DATA'
                }
                resolve(Data)
            }
        })
    })
}


module.exports.updatedata = (data)=>{
    return new Promise((resolve,reject)=>{
        id = data.id;
        email = data.email;
        const chk = `select * from usertbl where email = '${email}'`;
        client.query(chk,(err,res)=>{
            if(err)
            {
                const Data = {
                    "success":false,
                    "message":"semthing went worng"
                }
                resolve(Data)
            }
            else{
                if(res.rows.length>0){
                    const Data = {
                        "success":true,
                        "message":"already update"
                    }
                    resolve(Data)
                }
                else{
                   const sql = `update usertbl set email = '${email}' where id = '${id}'`
                   client.query(sql,(err,res)=>{
                       if(err)
                       {
                        const Data = {
                            "success":false,
                            "message":"error"
                        }
                        resolve(Data)
                       }
                       else{
                        const Data = {
                            "success":true,
                            "message":"update successfully"
                        }
                        resolve(Data)
                       }
                   })
                }
            }
        })
    })
}
// module.exports.updatedata = (data) => {
//     return new Promise((resolve, reject) => {
//         //console.log(data)
//         id = data.id;
//         email = data.email;
//         const sql4 = `update  usertbl set email= '${email}' where id= '${id}' `;
//         //console.log(sql2);
//         client.query(sql4, (err, res2) => {
//             if (err) {
//                 const Data = {
//                     "success": false,
//                     "message": 'Error occour'
//                 }
//                 resolve(Data)
//             } else {
//                 const Data = {
//                     "success": true,
//                     "message": 'ALL DATA'
//                 }
//                 resolve(Data)
//             }
//         })
//     })
// }
